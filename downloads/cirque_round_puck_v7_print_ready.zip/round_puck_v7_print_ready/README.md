# Cirque puck V7 — print-ready revision

This revises the exact second puck currently displayed on rocklabs.rocks. The finished enclosure remains **Ø46 × 13.5 mm** before the rubber feet.

## What changed for printing

- The top STL now prints **open seam down**, with its smooth exterior facing upward.
- All four heat-set bosses begin on the build plate and print vertically.
- The old unsupported horizontal sensor shelf is replaced by a **double-45° hourglass seat** with no horizontal lip.
- The exterior 1.2 mm top fillet is printed in its supported direction.
- The only meaningful bridge is the USB-C opening, up to 12.4 mm wide at its flared exterior mouth.
- Four small friction ribs use 45° lower and upper lead-ins; they provide light retention without requiring tape.
- The bottom stays flat under all four adhesive feet. Shallow 0.25 mm-wide circular outlines show placement without creating large pocket roofs to bridge.

Use `cirque_round_puck_v7_print_ready_print_plate.stl` to print both enclosure pieces in their intended orientations. The two individual STLs are already oriented correctly as well.

## Verified component envelopes

- Cirque TM040040: Ø40.0 mm, conservative 5.61 mm total envelope
- Trackpad connector: 12-pin vertical connector with 4.10 mm mechanical height
- Adafruit KB2040: conservative 35.0 × 17.8 × 4.9 mm product envelope
- Keycapsss/keyboard-magpie adapter PCB: exact 13.75 × 11.50 × 1.60 mm outline
- Adapter FFC connector: modeled at a conservative 3.0 mm above its PCB
- Four AWG30 conductors: reserved inside a 3.0 × 0.55 mm bundle envelope in an 8 mm-wide groove
- Four M2×4 heat-set inserts and four nominal M2×6 screws with D4 × 2 mm head envelopes
- Four Ø10 mm adhesive rubber feet on flat exterior pads

The generated assembly STEP contains all of these conservative component envelopes for inspection.

## Important adapter-header instruction

Do **not** install the supplied 4-pin header upright. Solder the AWG30 wires directly into the four adapter holes and trim the solder tails flush. A normal full-length upright header plus soldered wires is too tall for a 13.5 mm puck. Direct wiring uses only the parts already being purchased.

## Suggested print settings

- PETG preferred; PLA is acceptable after a successful fit test
- 0.20 mm layer height
- Four perimeters
- Five top/bottom layers
- 25–35% infill
- No supports
- Add a 3–5 mm brim to the top shell because its bed-contact face is a narrow annulus

Print `cirque_round_puck_v7_print_ready_sensor_fit_test.stl` first. This short ring reproduces the real double-45° seat, rib height, and print direction. The general opening has 0.30 mm radial clearance, while the four local ribs intentionally grip the sensor by about 0.08 mm radially. Lightly file only the ribs if your printer runs tight; do not force the PCB. Retention is printer-tolerance dependent, so do not proceed with the full shell if the test ring is loose—adjust hole/XY compensation or ask for a tighter-rib export.

## Assembly order

1. Print the fit test and verify that the trackpad enters with light, even resistance.
2. Install four M2×4 heat-set inserts from the bottom seam of the top shell.
3. Push the trackpad into the top opening until it self-centres flush in the hourglass seat.
4. Place the KB2040 and adapter between the small locating stops on the bottom plate.
5. Connect the included FFC and route its bend at the adapter side. Direct-solder four short AWG30 wires.
6. Fit your actual USB-C plug before closing to confirm that its moulded body reaches through the flared port; cable overmould sizes vary.
7. Close with four M2 screws and apply the four rubber feet inside the shallow circular placement outlines.

The bottom counterbores recess the first 0.9 mm of an M2 head. A head up to about D4 × 2 mm may protrude by roughly 1.1 mm, but it remains well inside the 4.5 mm rubber-foot stand-off.

## Files

- `..._print_plate.stl` — both enclosure pieces, ready to slice
- `..._top.stl` / `..._bottom.stl` — separate print-ready parts
- `..._top.step` / `..._bottom.step` — editable CAD parts
- `..._assembly_with_components.step` — enclosure plus conservative fit envelopes
- `..._sensor_fit_test.stl` — quick tolerance test
- `..._cutaway_shell.stl` / `..._cutaway_components.stl` — inspection aids, not print parts
